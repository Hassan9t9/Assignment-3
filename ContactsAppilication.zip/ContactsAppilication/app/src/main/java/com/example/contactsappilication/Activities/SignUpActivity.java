package com.example.contactsappilication.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.contactsappilication.Activities.ContactsActivity;
import com.example.contactsappilication.Activities.SignInActivity;
import com.example.contactsappilication.R;
import com.google.android.material.textfield.TextInputLayout;

public class SignUpActivity extends AppCompatActivity implements View.OnTouchListener , View.OnClickListener {

    private EditText nameTextInput;
    private EditText emailTextInput;
    private TextInputLayout passwordInput;
    private TextView signInButton;
    private Button signUpButton;
    private EditText passwordInputEditText;

    private ImageView backBtn;
    private TextView backTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        setListeners();
    }

    private void setListeners() {
        signUpButton.setOnClickListener(this);
        signInButton.setOnClickListener(this);
        nameTextInput.setOnTouchListener(this);
        emailTextInput.setOnTouchListener(this);
        backBtn.setOnClickListener(this);
        backTextView.setOnClickListener(this);
        passwordInput.setOnTouchListener(this);
    }

    private void initViews() {
        signUpButton = findViewById(R.id.sign_up_button);
        nameTextInput = findViewById(R.id.name_text_input);
        backBtn = findViewById(R.id.back_btn);
        backTextView = findViewById(R.id.back_text_view);
        emailTextInput = findViewById(R.id.email_text_input);
        passwordInputEditText = findViewById(R.id.password_input);
        passwordInput = findViewById(R.id.password_text_input);
        signInButton = findViewById(R.id.sign_in_button);

    }


    @Override
    public boolean onTouch(View v, MotionEvent event) {
        v.setFocusable(true);
        v.setFocusableInTouchMode(true);
        return false;
    }


    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sign_in_button:
                startSignInActivity();
                break;

            case R.id.sign_up_button:
                if(validInputs()) {
                    startContactsActivity();
                }
                break;

            case R.id.back_btn :

            case R.id.back_text_view:
                finish();
                break;
        }
    }

    private void setError() {
        if(nameTextInput.getText().toString().isEmpty()){
            nameTextInput.setError("Field is required");
        }
        if(emailTextInput.getText().toString().isEmpty()){
            emailTextInput.setError("Field is required");
        }
        if(passwordInput.getEditText().getText().toString().isEmpty()){
            passwordInput.setError("Field is required");
        }
    }

    private void startContactsActivity() {
        Intent intent = new Intent(this, ContactsActivity.class);
        startActivity(intent);
    }

    private boolean validInputs() {
        if(!nameTextInput.getText().toString().isEmpty() && !emailTextInput.getText().toString().isEmpty() && !passwordInput.getEditText().getText().toString().isEmpty()){
            return true;
        }else{
            setError();
            return false;
        }
    }

    private void startSignInActivity() {
        Intent intent = new Intent(this, SignInActivity.class);
        startActivity(intent);
    }
}