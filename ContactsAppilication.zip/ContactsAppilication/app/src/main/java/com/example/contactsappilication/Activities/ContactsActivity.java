package com.example.contactsappilication.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactsappilication.Listeners.AdapterViewItemClickedListener;
import com.example.contactsappilication.Dtos.Contact;
import com.example.contactsappilication.Adapters.ContactsAdapter;
import com.example.contactsappilication.R;

import java.util.ArrayList;
import java.util.List;

public class ContactsActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView contactsRecyclerView;
    private List<Contact> contactList = new ArrayList<>();
    private LinearLayoutManager layoutManager;
    private ImageView backtn;
    private ContactsAdapter contactsAdapter;
    private TextView contactListTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);
        initViews();
        setListeners();
        insertDataIntoList();
        setUpRecyclerView();
    }

    private void setListeners() {
        backtn.setOnClickListener(this);
        contactListTextView.setOnClickListener(this);
    }

    private void insertDataIntoList() {
        contactList.add(new Contact("Ali",R.drawable.male));
        contactList.add(new Contact("Faizan",R.drawable.female));
        contactList.add(new Contact("Hassan",R.drawable.male));
        contactList.add(new Contact("Salma",R.drawable.female));
        contactList.add(new Contact("Farukh",R.drawable.male));
        contactList.add(new Contact("Haroon",R.drawable.female));
        contactList.add(new Contact("Moshin",R.drawable.male));
        contactList.add(new Contact("Hassan",R.drawable.female));
        contactList.add(new Contact("Khulda",R.drawable.male));
        contactList.add(new Contact("Aina",R.drawable.female));
        contactList.add(new Contact("Maryum",R.drawable.male));
        contactList.add(new Contact("Amina",R.drawable.male));
        contactList.add(new Contact("Ifrah",R.drawable.female));
        contactList.add(new Contact("Bisma",R.drawable.male));
        contactList.add(new Contact("Ambreen",R.drawable.female));
        contactList.add(new Contact("Khulda",R.drawable.female));
        contactList.add(new Contact("Tahreem",R.drawable.female));
        contactList.add(new Contact("Faryal",R.drawable.male));
        contactList.add(new Contact("Haroon",R.drawable.female));
        contactList.add(new Contact("Faizan",R.drawable.male));
    }

    private void setUpRecyclerView() {
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        contactsRecyclerView.setLayoutManager(layoutManager);
        contactsAdapter = new ContactsAdapter(contactList, this,adapterViewItemClickedListener);
        contactsRecyclerView.setAdapter(contactsAdapter);
    }

    private void initViews() {
        contactsRecyclerView = findViewById(R.id.contacts_recycler_view);
        backtn = findViewById(R.id.back_btn);
        contactListTextView = findViewById(R.id.contact_list);
    }

    private AdapterViewItemClickedListener adapterViewItemClickedListener = new AdapterViewItemClickedListener() {
        @Override
        public void onAdatviewItemClicked(int position) {
            Intent intent = new Intent(ContactsActivity.this, ContactDetailActivity.class);
            intent.putExtra("image",contactList.get(position).getIconURL());
            intent.putExtra("name",contactList.get(position).getName());
            startActivity(intent);

        }

        @Override
        public void onAdatviewItemClicked(int position, int requestID) {

        }
    };

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.back_btn:
                finish();
                break;

            case R.id.contact_list:
                finish();
                break;
        }
    }
}