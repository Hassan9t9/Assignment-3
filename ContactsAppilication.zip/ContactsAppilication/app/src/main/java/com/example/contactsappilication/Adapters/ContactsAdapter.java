package com.example.contactsappilication.Adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.contactsappilication.Listeners.AdapterViewItemClickedListener;
import com.example.contactsappilication.Dtos.Contact;
import com.example.contactsappilication.Viewholders.ContactViewHolder;
import com.example.contactsappilication.R;

import java.util.ArrayList;
import java.util.List;

public class ContactsAdapter extends RecyclerView.Adapter<ContactViewHolder> {

    private List<Contact> contactList = new ArrayList<>();
    private Context context;
    private AdapterViewItemClickedListener adapterViewItemClickedListener;

    public ContactsAdapter(List<Contact> contactList, Context context, AdapterViewItemClickedListener adapterViewItemClickedListener) {
        this.contactList = contactList;
        this.context = context;
        this.adapterViewItemClickedListener = adapterViewItemClickedListener;
    }

    @NonNull
    @Override
    public ContactViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.contact_repeator, parent, false);
        return new ContactViewHolder(itemView, adapterViewItemClickedListener);
    }

    @Override
    public void onBindViewHolder(@NonNull ContactViewHolder holder, int position) {
        Glide.with(context).load(contactList.get(position).getIconURL()).circleCrop().into(holder.getImage());
        holder.getName().setText(contactList.get(position).getName());
    }

    @Override
    public int getItemCount() {
        return contactList.size();
    }
}
