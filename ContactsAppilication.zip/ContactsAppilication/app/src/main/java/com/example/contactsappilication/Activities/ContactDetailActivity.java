package com.example.contactsappilication.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.contactsappilication.R;

public class ContactDetailActivity extends AppCompatActivity {


    private ImageView bigImage;
    private ImageView smallImage;
    private TextView contactName;
    private TextView contactNumber;
    private TextView email;

    private int image;
    private String name;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_detail);
        initViews();
        receiveIntent();
        setData();
    }

    private void setData() {
        Glide.with(this).load(image).circleCrop().into(bigImage);
        Glide.with(this).load(image).circleCrop().into(smallImage);
        contactName.setText(name);
        email.setText(name + "@gmail.com");
    }

    private void receiveIntent() {
        Intent intent = getIntent();
        name = intent.getStringExtra("name");
        image = intent.getIntExtra("image", 0);
    }

    private void initViews() {
        bigImage = findViewById(R.id.big_image);
        smallImage = findViewById(R.id.small_image);
        contactName = findViewById(R.id.name);
        contactNumber = findViewById(R.id.number);
        email = findViewById(R.id.email);

    }
}