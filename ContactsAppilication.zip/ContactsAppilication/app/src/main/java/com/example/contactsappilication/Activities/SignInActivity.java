package com.example.contactsappilication.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.contactsappilication.R;
import com.google.android.material.textfield.TextInputLayout;

public class SignInActivity extends AppCompatActivity implements View.OnTouchListener, View.OnClickListener {

    private EditText emailTextInput;
    private TextInputLayout passwordTextInput;
    private TextView signUpButton;
    private Button signInButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        initViews();
        setListeners();
    }

    private void setListeners() {
        emailTextInput.setOnTouchListener(this);
        passwordTextInput.setOnTouchListener(this);
        signInButton.setOnClickListener(this);
        signUpButton.setOnClickListener(this);

    }

    private void initViews() {
        emailTextInput = findViewById(R.id.email_text_input);
        passwordTextInput = findViewById(R.id.password_text_input);
        signUpButton = findViewById(R.id.sign_up_button);
        signInButton = findViewById(R.id.sign_in_button);

    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        v.setFocusable(true);
        v.setFocusableInTouchMode(true);
        return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.sign_up_button:
                Intent intent = new Intent(this, SignUpActivity.class);
                startActivity(intent);
                break;

            case R.id.sign_in_button:
                if(validInputs()){
                    startContactActivity();
                }
                break;
        }
    }

    private boolean validInputs() {
        if(!emailTextInput.getText().toString().isEmpty() && !passwordTextInput.getEditText().getText().toString().isEmpty()){
            return true;
        }else{
            setError();
            return false;
        }
    }

    private void setError() {
        if(emailTextInput.getText().toString().isEmpty()){
            emailTextInput.setError("Field is required");
        }
        if(passwordTextInput.getEditText().getText().toString().isEmpty()){
            passwordTextInput.setError("Field is required");
        }
    }

    private void startContactActivity() {
        Intent intent = new Intent(this, ContactsActivity.class);
        startActivity(intent);
    }
}