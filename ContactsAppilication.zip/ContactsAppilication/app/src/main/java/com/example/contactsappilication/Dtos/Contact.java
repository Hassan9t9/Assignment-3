package com.example.contactsappilication.Dtos;

public class Contact {

    private String name;
    private int iconURL;


    public Contact(String name, int iconURL) {
        this.name = name;
        this.iconURL = iconURL;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getIconURL() {
        return iconURL;
    }

    public void setIconURL(int iconURL) {
        this.iconURL = iconURL;
    }
}
