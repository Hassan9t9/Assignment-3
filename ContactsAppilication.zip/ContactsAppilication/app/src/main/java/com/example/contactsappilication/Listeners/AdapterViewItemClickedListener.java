package com.example.contactsappilication.Listeners;

public interface AdapterViewItemClickedListener {

    void onAdatviewItemClicked(int position);

    void onAdatviewItemClicked(int position, int requestID);
}
