package com.example.contactsappilication.Viewholders;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.contactsappilication.Listeners.AdapterViewItemClickedListener;
import com.example.contactsappilication.R;

public class ContactViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    private ImageView image;
    private TextView name;
    private ConstraintLayout parent;
    private AdapterViewItemClickedListener adapterViewItemClickedListener;

    public ContactViewHolder(@NonNull View itemView, AdapterViewItemClickedListener adapterViewItemClickedListener) {
        super(itemView);
        image= itemView.findViewById(R.id.image);
        name=  itemView.findViewById(R.id.name);
        parent = itemView.findViewById(R.id.parent);
        parent.setOnClickListener(this);
        this.adapterViewItemClickedListener = adapterViewItemClickedListener;
    }

    public ImageView getImage() {
        return image;
    }

    public TextView getName() {
        return name;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.parent:
                adapterViewItemClickedListener.onAdatviewItemClicked(getAdapterPosition());
                break;
        }
    }
}
